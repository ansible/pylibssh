# -*- coding: utf-8 -*-

"""Python bindings for libssh."""

from ._version import (  # noqa: F401, WPS300, WPS436
    __full_version__, __libssh_version__, __version__, __version_info__,
)
